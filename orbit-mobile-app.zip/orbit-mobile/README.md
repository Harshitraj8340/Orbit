# ORBIT student app

Today's classes, attendance and notices, plus Jinnu the AI instructor, agents, What-If simulator, document reader and team space.

## Option A: install it like an app (5 minutes, no coding)
1. Upload the `www` folder to any free host (Netlify Drop, GitHub Pages, Vercel). It must be served over https.
2. Open the link on your phone.
3. Android Chrome: menu, then "Install app". iPhone Safari: Share, then "Add to Home Screen".
It opens full screen with its own icon and works offline after the first visit.

## Option B: a real Android app (APK)
Needs Node.js 18+ and Android Studio.
1. `npm install`
2. `npx cap add android`
3. `npm run icons` (makes app icons from resources/icon.png)
4. `npm run sync`
5. `npm run android`, then in Android Studio choose Build > Build APK(s).
Install the APK on your phone, or publish it through Google Play.

## Option C: iPhone app
Needs a Mac with Xcode. Run `npx cap add ios`, `npm run sync`, `npm run ios`, then press Run.

## What works outside Claude
Everything works except the Claude-powered parts. Jinnu and the agents then give simple built-in answers about your classes, attendance and notices. Reading photos of notices and the mic button need the AI service. To bring them back, build a small server that calls the Claude API and have the app call it. Never put an API key inside the app.

## Next steps for a real product
- Replace the made-up timetable, attendance and notices with your college's data.
- Replace the demo login with a real sign-in.
